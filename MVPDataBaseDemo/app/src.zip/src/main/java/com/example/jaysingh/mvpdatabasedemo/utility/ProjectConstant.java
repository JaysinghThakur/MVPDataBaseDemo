package com.example.jaysingh.mvpdatabasedemo.utility;

/**
 * Created by jaysingh on 15/12/16.
 */

public class ProjectConstant {

    public static final int SPLASHTIME= 2000;



}
